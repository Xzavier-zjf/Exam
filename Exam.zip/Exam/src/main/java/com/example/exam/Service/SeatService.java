package com.example.exam.Service;

import com.example.exam.model.Seat;
import com.example.exam.respository.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SeatService {

    @Autowired
    private SeatRepository seatRepository;

    // 根据房间号获取座位列表
    public List<Seat> getSeatsByRoom(String room) {
        return seatRepository.findByExamRoom(room);  // 按房间号查询座位
    }

    // 手动编排座位
    public void manualSeatArrangement(String room, Map<String, String> seatAssignments) {
        for (Map.Entry<String, String> entry : seatAssignments.entrySet()) {
            // 查找座位
            Seat seat = seatRepository.findByExamRoomAndSeatNumber(room, Integer.parseInt(entry.getKey()));
            if (seat != null) {
                seat.setStudentName(entry.getValue().trim());  // 设置学生姓名
                seat.setAvailable(entry.getValue().isEmpty()); // 如果姓名为空，设置为可用
                seatRepository.save(seat);  // 保存座位
            }
        }
    }

    // 保存单个座位信息
    public void saveSeat(Seat seat) {
        seatRepository.save(seat);
    }
}



