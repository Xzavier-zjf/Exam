package com.example.exam.respository;



import com.example.exam.model.Exam;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ExamRepository extends JpaRepository<Exam, Long> {
    Optional<Exam> findByRoom(String room);   // 根据试室号查找考试
}
