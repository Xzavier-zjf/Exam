package com.example.exam.respository;



import com.example.exam.model.Seat;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface SeatRepository extends JpaRepository<Seat, Long> {

    List<Seat> findByExamRoom(String room);

    Seat findByExamRoomAndSeatNumber(String room, Integer seatNumber);

    List<Seat> findByExam_Room(String room);
}

