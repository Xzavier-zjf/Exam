package com.example.exam.Service;



import com.example.exam.model.Exam;
import com.example.exam.respository.ExamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ExamService {

    @Autowired
    private ExamRepository examRepository;

    public Optional<Exam> getExamByRoomNumber(String roomNumber) {
        return examRepository.findByRoom(roomNumber);
    }

    public void saveExam(Exam exam) {
        examRepository.save(exam);
    }

    public List<Exam> getAllExams() {
        return examRepository.findAll();  // 获取所有考试记录
    }
}
